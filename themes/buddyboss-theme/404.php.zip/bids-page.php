<?php
/**
 * Template name: Bids Template
 *
 * @package BuddyBoss_Theme
 */

get_header();
global $wpdb;
?>
	<?php 
	$share_box = buddyboss_theme_get_option( 'blog_share_box' ); 
	if ( !empty( $share_box ) && is_singular('post') ) :
		get_template_part( 'template-parts/share' ); 
	endif;
	?>
<style>
    #primary.content-area{}
    #primary.content-area::before{
        content: "";
        width: 100vw;
        height: 120px;
        position: absolute;
        top: 105px; left: 0;
        background: rgb(0,13,157);
background: linear-gradient(132deg, rgba(0,13,157,1) 0%, rgba(0,198,125,1) 100%);
    }
    
    #main.site-main h1{color: white; font-weight: 700;}
    .bids_list .row{
        display: grid; 
        grid-template-columns: 30px 30% 1fr 1fr 1fr;
        grid-gap: 20px;
        padding: 15px 0;
    }
    
    .bids_list .row:nth-child(odd){background: #e0e1eb;}
    .bids_list .row p{margin: 0; padding: 0; font-size: 13px; line-height: 1em;}
    .bids_list .row p a{font-size: 16px; color: #000daa;}
    
    .bids_list .row.head{background: #5fcf85; border-top-right-radius: 20px; border-top-left-radius: 20px;}
    .bids_list .row.head p{color: white; font-weight: 600; display: block;}
    
    .bids_list .row.head.footer{border-top-right-radius: 0px; border-top-left-radius: 0px; border-bottom-right-radius: 20px; border-bottom-left-radius: 20px;}
    @media(max-width: 940px){
        .bids_list .row{grid-template-columns: 30px 30% 1fr 1fr;}
        .bids_list .row > div:nth-child(3){display: none;}
    }
    
    @media(max-width: 740px){
        .bids_list .row{grid-template-columns: 30px 1fr 100px;}
        .bids_list .row.row_content  > div.aligncenter:nth-child(4){
            grid-column: 2/3;
            grid-row: 2/3;
            text-align: left;
        }
        .bids_list .row.row_content  > div.aligncenter:nth-child(3){
            text-align: left;
        }
        
        .bids_list .row  > div.aligncenter:nth-child(4) p{display: block; }
    }
    
    .search_bar{
        display: block; width: 100%;
        padding: 50px 0 0 0;
        
    }
    
    .search_bar .form{
        display: grid; width: 100%;
        grid-template-columns: 2fr 1fr 1fr 100px;
        grid-gap: 20px;
    }
    
    .search_bar .formfield{}
    .search_bar .formfield label{font-size: 13px;}
    .search_bar .formfield input[type=text]{display: block; width: 100%;}
    
    .search_bar .form .button{transform: translateY(27px);}
    
    .bids_list p, .bids_list .row p a{font-size: 14px;}
</style>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">
            
            <h1><?php echo $post->post_title; ?></h1>
            <div id="search_bar" class="search_bar">
                <form class="form">
                    <div class="formfield">
                        <label>Keyword </label>
                        <input type="text" id="search" name="search" placeholder="Keyword" value="<?php if(isset($_GET['search']) && strlen($_GET['search']) > 0){echo $_GET['search'];} ?>" />
                    </div>
                    <div class="formfield">
                        <label>Main topic </label>
                        <input type="text" id="search_topic" name="search_topic" placeholder="Main topic" value="<?php if(isset($_GET['search_topic']) && strlen($_GET['search_topic']) > 0){echo $_GET['search_topic'];} ?>" />
                    </div>
                    <div class="formfield">
                        <label>Location </label>
                        <input type="text" id="search_location" name="search_location" placeholder="Location" value="<?php if(isset($_GET['search_location']) && strlen($_GET['search_location']) > 0){echo $_GET['search_location'];} ?>" />
                    </div>
                    <div class="formfield">
                        <input type="submit" value="Search" class="button" />
                    </div>
                </form>
            </div>
            <div id="post_list" class="bids_list">
    
    <?php $w = array(); ?>
    <?php if(isset($_GET['search']) && strlen($_GET['search']) > 0){
            $q['key'] = "post_title";
            $q['value'] = esc_attr($_GET['search']);
            $q['compare'] = "like";
            
            $w[] = " (SELECT * FROM wp_posts LEFT JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id WHERE wp_posts.post_title LIKE '%" . $q['value'] . "%' LIMIT 300) ";
            
            $where[] = $q;
            
    }  
    
     if(isset($_GET['search_topic']) && strlen($_GET['search_topic']) > 0){
            $q['key'] = "category";
            $q['value'] = esc_attr($_GET['search_topic']);
            $q['compare'] = "like";
            
            $where[] = $q;
            $w[] = " (SELECT * FROM wp_posts LEFT JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id WHERE wp_postmeta.meta_key = 'category' AND wp_postmeta.meta_value LIKE '%" . $q['value'] . "%'  LIMIT 300) ";
            
    }  
    
    if(isset($_GET['search_location']) && strlen($_GET['search_location']) > 0){
            $q['key'] = "location";
            $q['value'] = esc_attr($_GET['search_location']);
            $q['compare'] = "like";
            
            $where[] = $q;
            $w[] = " (SELECT * FROM wp_posts LEFT JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id WHERE wp_postmeta.meta_key = 'location' AND wp_postmeta.meta_value LIKE '%" . $q['value'] . "%'  LIMIT 300) ";
            
    }  ?>
    <?php if(empty($where)): ?>
    <?php $posts = new WP_Query(array('post_type' => 'bid', 'posts_per_page' => 50, 'paged' => get_query_var('paged') ? get_query_var('paged') : 1 )); $is_search = false; ?>
    <?php $loop = $posts->posts; ?>
    
    <?php else: ?>
    <?php $where = array(); 
    
    
    $w_string = "SELECT bio_posts.ID, bio_posts.post_title FROM (" . implode(" UNION ", $w) . " ) AS bio_posts GROUP BY bio_posts.ID"; ?>
    <?php $q = $w_string; // echo $q; ?>
    <?php $loop = $wpdb->get_results($q);// print_r($loop); ?>
    <?php  $is_search = true; ?>
    <?php endif; ?>
    <div class="row head" >
    <div></div>
    <div><p>Title</p></div>
    <div class="aligncenter"><p>Main topic</p></div>
    <div class="aligncenter"><p>Location</p></div>
    <div class="aligncenter"><p>End Date</p></div>
</div>
<?php if(!empty($loop) > 0): ?>
<?php foreach($loop as $l):
        $post_title = $l->post_title;
        $cat = get_field("category", $l->ID);
        $category = ""; if(!empty($cat) > 0){$category =  implode(",", $cat);}
        $location = get_field("location", $l->ID); 
        $show_row = true;
        
        $true_results = 0;
        $total_checks = 0; 
        if($is_search){
            $show_row = false; 
            if(isset($_GET['search']) && strlen($_GET['search']) > 0){ 
                $total_checks++; 
               // echo "<p>" . $post_title . " : " . $_GET['search'] . "</p>";
                if(strpos(strtolower($post_title), strtolower($_GET['search']))){$true_results++; } 
            }
            
            if(isset($_GET['search_topic']) && strlen($_GET['search_topic']) > 0 && count($cat) > 0){
                $total_checks++; 
                //echo strtolower($category) . " : " . strtolower($_GET['search_topic']) . "<br/>";
                if(strpos(strtolower($category), strtolower($_GET['search_topic'])) || strtolower($category) == strtolower($_GET['search_topic'])){$true_results++;   }
            }
            
            if(isset($_GET['search_location']) && strlen($_GET['search_location']) > 0 ){
                $total_checks++;
                
                if(strpos(strtolower($location), strtolower($_GET['search_location']))){$true_results++;}
            }
            
            if($true_results >= $total_checks){$show_row = true;}
        }
        
        if($show_row): 
    ?>
<div class="row" id="row_<?php echo $l->ID; ?>"><?php $post_link = get_permalink($l->ID); ?>
    <div></div>
    <div class=""><p><a href="<?php echo $post_link; ?>"><?php echo $l->post_title; ?></a></p></div>
    <div class="aligncenter"><p><?php echo $category; ?></p></div>
    <div class="aligncenter"><p><?php echo $location; ?></p></div>
    <div class="aligncenter"><p><?php $closing_date = get_field("closing_date", $l->ID); echo $closing_date; ?></p></div>
</div>
<?php endif; endforeach; ?>
<?php else: ?>
<div class="row">
    <div></div>    
    <div>No results</div>
</div>
<?php endif; ?>
<div class="row head footer" >
    <div></div>
    <div><p>Title</p></div>
    <div class="aligncenter"><p>Main topic</p></div>
    <div class="aligncenter"><p>Location</p></div>
    <div class="aligncenter"><p>End Date</p></div>
</div>
  

<?php

$big = 999999999; // need an unlikely integer
 /*echo paginate_links( array(
    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'total' => $loop->max_num_pages
) ); */
?>

</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php //get_sidebar(); ?>

<?php
get_footer();
?>
<style>

.deck{
    display: block; padding: 20px 0;
}

.grid_2{
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 20px;
}

.single .entry-title {
    margin-top: -30px;
    
}
</style>
