<?php



/**

 * Template name: Jobs Listing Template

 *

 * @package BuddyBoss_Theme

 */



get_header();

global $wpdb;



$has_access = false;

if (current_user_can('editor') || current_user_can('administrator')) {

    $has_access = true;

}

$current_date = strtotime(date("Y-m-d"));

?>

<?php

$share_box = buddyboss_theme_get_option('blog_share_box');

if (!empty($share_box) && is_singular('post')) :

    get_template_part('template-parts/share');

endif;

?>







<link rel="stylesheet" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/bgcommunity.css?id=<?php echo rand(1000,9999); ?>" />



<script src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-grid-only@1.0.0/bootstrap.css">
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/bg-list.css?id=<?php echo rand(1000,9999); ?>">





<div id="primary" class="content-area">

    <main id="main" class="site-main">


        <div class="flex grid_flex">
            <div><h1><?php echo $post->post_title; ?><sup>(<span class="no_items">0</span>)</sup> </h1></div>
            <div><a href="<?php echo site_url() . '/add-career/'; ?>" class="button ">+ Add your job posting</a></div>
        </div>

        <div id="post_list" class="bids_list" style="">

            <div class="row bg_form_fields">
                <div class="col-sm-6">
                    <p>Filter by:</p>
                </div>
                <div class="col-sm-6">
                    
                    <input type="text" id='keyword' name="keyword" placeholder="Keyword" class="form-control">
                </div>  

                <div class="col-sm-6 select_wrapper">
                    <span id="Country" placeholder="Country"></span>
                </div>
            </div>
            
                
                <!--
                <div class="col-sm-6">
                    <p>Main Topic</p>
                    <span id="Topic"></span>
                </div>
                -->
                <div class="row">
                <div class="col-sm-12" style="padding: 25px 0px 0px 0px;" >
                    <h3 >THERE ARE CURRENTLY <span id='bidsNum' style="font-weight:bold"></span> JOB OPPORTUNITIES ON BIOGAS COMMUNITY</h3>
                </div>

            </div>


            <?php     

            $date_args = array(
                'post_type'   => 'career_jobs',
                'meta_key' => 'deadline_to_apply',
                'posts_per_page' => -1,
                'orderby' => 'meta_value_num',
                'post_status' => 'publish',
                'order' => 'ASC',
                'meta_query'=> array(
                    array(
                    'key' => 'deadline_to_apply',
                    'compare' => '>=',
                    'value' => date("Y-m-d"),
                    'type' => 'DATE'
                    )
                ),
            );
            $query = new WP_Query( $date_args );






            $query = $query->posts;


            




            ?>



            <?php

                
                

            ?>

            <table class='sortable display responsive' id='Tableau' style="width:100%">

                <thead>
                    <th>Title</th>
                    <th>Job Domain</th>
                    <th>Location</th>
                    <th>End Date</th>
                </thead>

                <tbody>
                    <?php $k = 0; foreach ($query as $value) : ?>

                        <?php
                            $post_id = intval(get_post_meta( $value->ID, 'company')[0]);                
                            $post_id = intval(get_post_meta( $post_id, 'logo')[0]);
                            $logo_url = get_site_url()."/wp-content/uploads/".get_post_meta( $post_id, '_wp_attached_file')[0];
                        ?>

                        <tr>
                            <td><a href="<?= $value->guid; ?>"><?= $value->post_title; ?></a></td>
                            <td><?= get_field("job_domain", $value->ID);   ?></td>
                            <td><?= get_field("location", $value->ID); ?> a</td>
                            <td  class="nowrap"><?= date('Y-m-d',strtotime(get_field("deadline_to_apply", $value->ID))); ?></td>
                        </tr>


                    <?php endforeach ?>

                </tbody>

            </table>



            <style>

                @media only screen and (min-width: 600px) {
                    .first_column{width:35px!important}
                }

                @media only screen and (max-width: 600px) {
                    .first_column{width:200px!important}
                }
                

                #Tableau_length,#Tableau_filter {display: none;}

                .col-sm-6>input,.col-sm-6>span>select {width: 100%;}
                @media(min-width: 1200px){
                    .col-sm-6>input::placeholder{font-size: 20px;}    
                }

                .col-sm-6 {padding: 10px;}

                .col-sm-6>p {margin-bottom: 10px;}

                thead>tr {background: #00d37d;color: white;border-radius: 67px;}

                td {vertical-align: revert;}

                table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
                    background-color: #000daa!important;
                }

                #primary.content-area::before {
                    content: "";
                    width: 100vw;
                    height: 110px;
                    position: absolute;
                    top: 105px;
                    left: 0;
                    background: rgb(0,13,157);
                    background: linear-gradient(
                132deg, rgba(0,13,157,1) 0%, rgba(0,198,125,1) 100%);
                }
            </style>





            <script>

                jQuery(document).ready(function() {

                    $('#bidsNum').html('<?= count($query) ;?>');

                    jQuery('#keyword').keyup(function() {
                        oTable.search(jQuery(this).val()).draw();
                    });



                    oTable = $('#Tableau').DataTable({                  

                        "order": [
                            [0, 'desc'],
                            [3, "asc"]
                        ],

                        "pageLength": 50,
                        responsive: true,
                        initComplete: function() {

                            var i = 0;

                            var Ids = ["#Topic", /* "#Type",*/ "#Country"];



                            this.api().columns().every(function() {



                                var column = this;



                                if (i > 0) {

                                    var select = $('<select class=\'form-control\' ><option value=""></option></select>')

                                        .appendTo($(Ids[i - 1]).empty())

                                        .on('change', function() {

                                            var val = $.fn.dataTable.util.escapeRegex(

                                                $(this).val()

                                            );



                                            column

                                                .search(val ? '^' + val + '$' : '', true, false)

                                                .draw();

                                        });



                                    column.data().unique().sort().each(function(d, j) {

                                        select.append('<option value="' + d + '">' + d + '</option>')

                                    });



                                }

                                i = i + 1;

                            });

                        }

                    });

                    $('#container').css( 'display', 'block' );
                    oTable.columns.adjust().draw();



                    // Remonter en haut du tableau lorsque l'utilisateur change de page dans le tableau

                    /*

                    oTable.on('page.dt', function() {

                        jQuery('html, body').animate({

                            scrollTop: jQuery("#exclusivebids").offset().top

                        }, 'slow');

                    });

                    */

                });

            </script>







































            <?php



            $big = 999999999; // need an unlikely integer



            ?>



        </div>

    </main><!-- #main -->

</div><!-- #primary -->



<?php //get_sidebar(); 

?>



<?php

get_footer();

?>
<?php include(get_template_directory() . "/assets/includes/promo-footer.php");  ?>
<?php include(get_template_directory() . "/assets/includes/bg-footer.php");  ?>

<style>

    .deck {

        display: block;

        padding: 20px 0;

    }



    .grid_2 {

        display: grid;

        grid-template-columns: 1fr 1fr;

        grid-gap: 20px;

    }



    .single .entry-title {

        margin-top: -30px;



    }

</style>
<style>

                #Tableau_length,#Tableau_filter {display: none;}

                .col-sm-6>input,.col-sm-6>span>select {width: 100%;}

                .col-sm-6 {padding: 10px;}

                .col-sm-6>p {margin-bottom: 10px;}

                thead>tr {background: #006633;color: white;border-radius: 67px;}

                td {vertical-align: revert;}

                table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
                    background-color: #000daa!important;
                }
table.dataTable thead th, table.dataTable thead td {
padding: 25px 5px;
    
}

table.dataTable thead th, table.dataTable tfoot th{font-weight: initial;}
    

table.dataTable.display tbody tr.odd>.sorting_2, table.dataTable.order-column.stripe tbody tr.odd>.sorting_2, table.dataTable.display tbody tr.even>.sorting_2, table.dataTable.order-column.stripe tbody tr.even>.sorting_2{
    background-color: #D2E4DA;
}

table.dataTable.display tbody tr.odd>.sorting_1, table.dataTable.order-column.stripe tbody tr.odd>.sorting_1{background-color: initial;

body.bb-custom-typo{font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;}

tbody > tr >td:nth-child(2){background-color: #D2E4DA;}
tbody > tr{border-bottom: 1px solid #006633;}
td, th{border-bottom: 1px solid #006633;}
body > tr >td:nth-child(2){background-color: #d2E4D1;}

.col-sm-6>input, .col-sm-6>span>select{
    font-size: 12px; color: #006633;
}
</style>
<script>
    jQuery(document).ready(function(){
        updateNoItems();
        addPlaceHolders();
        
        setInterval(updateNoItems, 1000);
    });
    
    function updateNoItems(){
        var no_items = $("#bidsNum").html();
        
        jQuery('.no_items').html(no_items);
    }
    
    function addPlaceHolders(){
        var no_select = jQuery(".select_wrapper").size();
        
        for(var i = 0; i < no_select; i++){
            var select_title = jQuery(".select_wrapper:eq(" + i + ") span").attr("placeholder");
            //jQuery(".select_wrapper:eq(" + i + ") select").prepend('<option value="">' + select_title + '</option>');
            jQuery(".select_wrapper:eq(" + i + ") select option:first-child").html(select_title);
            jQuery(".select_wrapper:eq(" + i + ") select").addClass("unselected");
        }
    }
</script>















