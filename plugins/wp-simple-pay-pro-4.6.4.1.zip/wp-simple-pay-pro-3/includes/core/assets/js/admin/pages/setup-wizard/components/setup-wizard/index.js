/**
 * Internal dependencies
 */
import { Container } from './styles.js';

export function SetupWizard( props ) {
	return <Container { ...props } />;
}
