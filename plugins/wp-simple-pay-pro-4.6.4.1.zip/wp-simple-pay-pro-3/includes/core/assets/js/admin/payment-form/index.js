import './general.js';
import './prices.js';
import './payment-methods.js';
import './taxes.js';
import './custom-fields.js';
import './stripe-checkout.js';
import './payment-page.js';
import './purchase-restrictions.js';
