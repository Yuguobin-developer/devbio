/**
 * Internal dependencies
 */
import { LineItem as BaseLineItem } from '@wpsimplepay/cart';

/**
 * LineItem
 */
class LineItem extends BaseLineItem {}

export default LineItem;
