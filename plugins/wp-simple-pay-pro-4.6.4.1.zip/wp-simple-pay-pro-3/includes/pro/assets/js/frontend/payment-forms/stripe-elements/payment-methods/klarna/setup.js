/**
 * Sets up the Klarna Payment Method.
 *
 * @since 4.5.0
 */
function setup() {}

export default setup;
