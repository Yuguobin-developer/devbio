/**
 * Sets up the Alipay Payment Method.
 *
 * @since 4.2.0
 */
function setup() {}

export default setup;
