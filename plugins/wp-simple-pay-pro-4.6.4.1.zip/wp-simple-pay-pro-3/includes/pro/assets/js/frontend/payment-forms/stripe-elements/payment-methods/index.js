/**
 * Internal dependencies
 */
import './ach-debit';
import './afterpay-clearpay';
import './alipay';
import './bancontact';
import './card';
import './fpx';
import './giropay';
import './ideal';
import './klarna';
import './p24';
import './payment-request';
import './sepa-debit';
