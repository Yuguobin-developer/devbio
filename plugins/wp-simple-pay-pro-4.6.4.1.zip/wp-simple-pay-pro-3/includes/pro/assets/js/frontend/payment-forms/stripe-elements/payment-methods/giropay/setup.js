/**
 * Sets up the giropay Payment Method.
 *
 * @since 4.2.0
 */
function setup() {}

export default setup;
