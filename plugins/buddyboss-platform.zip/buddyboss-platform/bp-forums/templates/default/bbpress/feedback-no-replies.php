<?php

/**
 * No Replies Feedback Part
 *
 * @package BuddyBoss\Theme
 */

?>

<div class="bp-feedback info">
	<span class="bp-icon" aria-hidden="true"></span>
	<p><?php _e( 'No replies added here yet.', 'buddyboss' ); ?></p>
</div>
