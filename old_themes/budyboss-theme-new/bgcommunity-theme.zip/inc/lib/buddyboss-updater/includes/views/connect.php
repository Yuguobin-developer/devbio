<div id="bb_connector_overlay_wrapper" style="display: none;">
    <div id="bb_connector_overlay">
        <img src="<?php echo home_url( 'wp-includes/images/spinner-2x.gif' ); ?>">
    </div>
</div>